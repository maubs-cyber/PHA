import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { Overview } from '../components/Overview';
import { Clients } from '../components/Clients';
import { Requests } from '../components/Requests';

export const Dashboard: React.FC = () => {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Overview />} />
        <Route path="/clients" element={<Clients />} />
        <Route path="/requests" element={<Requests />} />
      </Routes>
    </Layout>
  );
};