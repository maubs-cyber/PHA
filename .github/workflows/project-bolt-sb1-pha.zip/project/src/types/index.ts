export interface User {
  id: string;
  email: string;
  role: 'broker' | 'client';
  created_at: string;
}

export interface Policy {
  id: string;
  client_id: string;
  policy_number: string;
  type: string;
  status: string;
  effective_date: string;
  created_at: string;
}

export interface Request {
  id: string;
  client_id: string;
  policy_id: string;
  type: string;
  status: 'incoming' | 'pending' | 'completed';
  description: string;
  created_at: string;
}