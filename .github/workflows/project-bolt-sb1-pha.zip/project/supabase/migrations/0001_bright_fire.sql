/*
  # Initial Schema Setup for Passionate Heart Broker

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `role` (text)
      - `created_at` (timestamp)
    
    - `policies`
      - `id` (uuid, primary key)
      - `client_id` (uuid, foreign key)
      - `policy_number` (text)
      - `type` (text)
      - `status` (text)
      - `effective_date` (date)
      - `created_at` (timestamp)
    
    - `requests`
      - `id` (uuid, primary key)
      - `client_id` (uuid, foreign key)
      - `policy_id` (uuid, foreign key)
      - `type` (text)
      - `status` (text)
      - `description` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  role text NOT NULL CHECK (role IN ('broker', 'client')),
  created_at timestamptz DEFAULT now()
);

-- Create policies table
CREATE TABLE IF NOT EXISTS policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  policy_number text NOT NULL,
  type text NOT NULL,
  status text NOT NULL,
  effective_date date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create requests table
CREATE TABLE IF NOT EXISTS requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  policy_id uuid REFERENCES policies(id) ON DELETE CASCADE,
  type text NOT NULL,
  status text NOT NULL CHECK (status IN ('incoming', 'pending', 'completed')),
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE requests ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Brokers can view all profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (role = 'broker');

CREATE POLICY "Clients can view own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id AND role = 'client');

-- Create policies for policies
CREATE POLICY "Brokers can view all policies"
  ON policies
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'broker'
  ));

CREATE POLICY "Clients can view own policies"
  ON policies
  FOR SELECT
  TO authenticated
  USING (client_id = auth.uid());

-- Create policies for requests
CREATE POLICY "Brokers can view all requests"
  ON requests
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'broker'
  ));

CREATE POLICY "Clients can view own requests"
  ON requests
  FOR SELECT
  TO authenticated
  USING (client_id = auth.uid());